package kalan.ozan.weathercodechallenge.api.model;


public class SearchError {

    public String msg;

    public String getError() {
        return msg;
    }
}
