package kalan.ozan.weathercodechallenge.api.model;

public class Astronomy {
    public String moonrise;
    public String moonset;
    public String sunrise;
    public String sunset;

    public String getMoonrise() {
        return moonrise;
    }

    public String getMoonset() {
        return moonset;
    }

    public String getSunrise() {
        return sunrise;
    }

    public String getSunset() {
        return sunset;
    }
}
