package kalan.ozan.weathercodechallenge.api.model;

public class Climate {
   public MyData data;
}

